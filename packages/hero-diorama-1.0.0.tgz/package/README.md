# Hero diorama

A white, isometric city drawn with three.js, for a hero banner or a page
section: a lone walker heads away from the camera, leaving a digital footprint,
while thin dark attack lines reach for them and a blue shield keeps them safe.
It fills a container of any size and follows its resizes.

It is a framework-free ESM module. `three` is a peer dependency: the page
brings its own copy (see `docs/adr/0001-three-as-peer-dependency.md`).

## Installation

This section is for a site with a build step (Vite, webpack, Parcel…) whose
own `package.json` provides `three`.

The package isn't on a registry. Install it straight from this repository, at
a version tag, beside a compatible `three`:

```sh
npm install three@^0.187.0 \
  "git+ssh://git@bitbucket.bitdefender.biz:7999/websites/hero-diorama.git#v1.0.0"
```

The site's `package.json` then lists
`"hero-diorama": "git+ssh://…/hero-diorama.git#v1.0.0"`, and its lockfile
pins the tag's commit. To upgrade, change the tag.

- **Access.** The install clones the repository, so it needs the same access
  as `git clone`: an SSH key registered with Bitbucket, on developers'
  machines and in the site's CI. Over HTTPS, use
  `git+https://bitbucket.bitdefender.biz/scm/websites/hero-diorama.git#v1.0.0`
  with credentials git can find (a credential helper, or an access token).
- **Nothing to build.** Each version tag carries the built files (`dist/`),
  so the install only copies them: the site never builds this project and
  doesn't get its build tools. Only tags are installable this way. A branch
  or a plain commit has no `dist/`, and the import fails.
- **`three`.** The diorama needs `three` 0.187 or newer, below 1.0. It is
  built and tested against 0.187. If the site already depends on `three` in
  that range, there is nothing more to install, and `npm ls three` shows one
  copy (`hero-diorama` lists it as `deduped`). npm refuses to install
  alongside a `three` outside the range. With a newer `three`, a
  `hero-diorama: three’s AO denoise shader has changed` warning in the console
  means the contact shadows lost their smoothing: pin `three` to 0.187.
- **TypeScript.** The package ships its typings. They don't refer to `three`'s
  types, so the site needs `@types/three` only if it uses `three` itself.

Use it from the site's code:

```js
import { createDiorama } from 'hero-diorama';

const diorama = createDiorama(document.querySelector('.hero'));
```

The container needs a size of its own (the canvas fills it at 100% × 100%).
`createDiorama` touches the DOM and WebGL, so in a server-rendered app call it
in the browser only (after mount).

### The walker model

The walker is a separate file, `models/walker.glb` (about 520 KB), shipped
next to the bundle in `dist/`. The bundle finds it with
`new URL('./models/walker.glb', import.meta.url)`, so the site's bundler copies
it into the build with a hashed name, like any imported asset, and nothing
needs configuring. This was checked with a Vite 7 build and a webpack 5 build.
Parcel handles the same pattern.

**Vite's dev server needs one line.** It pre-bundles dependencies into
`node_modules/.vite/deps/`, which breaks the relative URL: the model request
gets the HTML page back, `data-walker` reads `failed`, and the city runs
without the walker. Exclude the package from pre-bundling:

```js
// vite.config.js
import { defineConfig } from 'vite';

export default defineConfig({
  optimizeDeps: { exclude: ['hero-diorama'] },
});
```

Production builds (`vite build`) work with or without it.

**Hosting the model yourself.** A setup that copies only the JavaScript
(esbuild, Rollup without an asset plugin, a CDN for the bundle) leaves the
model behind. Copy `node_modules/hero-diorama/dist/models/walker.glb` to the
site's static files and pass its URL:

```js
createDiorama(el, { modelUrl: '/static/walker.glb' });
```

Set `modelUrl` the same way to load a different model. If the model can't be
loaded, the canvas's `data-walker` reads `failed`, the console logs one
`hero-diorama: could not load the walker model` warning, and the city runs on
without the walker.

## API

```js
const diorama = createDiorama(container, options); // options are optional
diorama.update(options); // merges over the current options
diorama.pause();         // stops drawing until resume()
diorama.resume();
diorama.dispose();       // removes the canvas, frees the GPU, drops every listener
```

`createDiorama(container, options)` adds a canvas to `container` and returns a
`Diorama`. Options left out keep their defaults; `update()` changes only the
ones it is given and keeps the rest. Out-of-range values are clamped, not
rejected. `DEFAULT_OPTIONS` is exported, as are the types `Diorama`,
`DioramaOptions`, `ResolvedOptions`, `FocalPoint`, `Intensity` and `Quality`.

A new `seed` builds a new city and restarts the walk at its opening. A new
`modelUrl` loads that model. Everything else applies on the next frame.

## Options

| Option | Default | Range | What it does |
| --- | --- | --- | --- |
| `background` | `"#F5F6F7"` | a CSS colour, or `"transparent"` | Behind the city and at the edge fade. Transparent lets the page show through, with slightly simpler shadows. |
| `accentColor` | `"#006DFF"` | a CSS colour | Shield, footprints, data trail and badge glyphs. |
| `threatColor` | `"#111111"` | a CSS colour | Attack lines. |
| `focalPoint.x` | `0.5` | 0–1 | Where the walker stands across the container, as a fraction of its width (0 is the left edge). Move it to leave room for a headline. |
| `focalPoint.y` | `0.5` | 0–1 | Where the walker stands down the container, as a fraction of its height (0 is the top). Either coordinate can be given alone. |
| `zoom` | `1` | ≥ 0.25 | Scales the city. At 1 the walker is about 18% of the container's shorter side, and at least 14 units of city show across. |
| `azimuth` | `45` | degrees | The camera's turn around the walker. At 45 they walk straight up the frame. |
| `elevation` | `35.26…` | 1–89 degrees | The camera's angle above the ground. The default is true isometric, atan(1/√2). |
| `seed` | `38` | a number | The city's layout. 38 is chosen for its opening frame: buildings on both sides of the walker at every preset (`npm run find-opening` finds others). |
| `density` | `0.5` | 0–1 | How built-up the city is. |
| `walkSpeed` | `1` | 0, or 0.25–2 | 0 freezes the walk; small positive speeds are raised to 0.25. |
| `footprintPoints` | `8` | 1–16, whole | How many points leave each footprint. Rounded and clamped. Separate from `intensity.footprint` (their strength); a change applies from the next footprint on. |
| `intensity.footprint` | `0.6` | 0–1 | The footprints. 0 turns an effect off. |
| `intensity.dataStream` | `0.4` | 0–1 | The fragments that peel off the walker. |
| `intensity.dataTrail` | `0` (off) | 0–1 | The accent trace bundle under the fragments. |
| `intensity.attack` | `0.3` | 0–1 | How many attack lines at once (at most 5), never how fast. At 0.3, one every 2–3.5 s. |
| `intensity.shield` | `0.5` | 0–1 | The shield's dots. At 0, attack lines still stop at the same radius, with no answer. |
| `quality` | `"auto"` | `"auto"`, `"low"`, `"high"` | See below. |
| `maxPixelRatio` | `2` | > 0 | The most device pixels per CSS pixel the canvas uses. `"auto"` and `"low"` cap it lower. |
| `modelUrl` | `models/walker.glb` next to the bundle | a URL | The walker's GLB (see [The walker model](#the-walker-model)). |

### Quality

- **`"auto"`** (default) starts at the default look: half-resolution ambient
  occlusion, 1024 shadows, no MSAA, tilt-shift, and FXAA under the lines, at a
  pixel ratio of at most 1.5. Before the canvas shows, a short probe (at most
  about 2 s) checks that the machine holds it; the container's own background
  shows meanwhile, then the canvas fades in. A browser that caps frames (Safari
  in Low Power Mode, at 30 fps) is judged against its cap. After the reveal it
  steps down only after about 4 s of slow frames, and never steps back up. Its
  steps, in order: the default; without tilt-shift (the same as `"low"`);
  without FXAA; last, a pixel ratio of 1.
- **`"low"`** is the default look without tilt-shift, at
  `min(maxPixelRatio, 1.5)`. It never costs more than `"auto"`.
- **`"high"`** is the full look (4× MSAA, full-resolution ambient occlusion,
  2048 shadows) at `maxPixelRatio`. It is for screenshots and video capture,
  and **does not hold 60 fps on most machines**: about 13 fps at 1920×800 @2×
  on an M1 Pro, about 26 at a pixel ratio of 1.5.

## The canvas's attributes

The canvas is `aria-hidden` and ignores the pointer. It reports its state in
data attributes, for the page's CSS or scripts:

| Attribute | Values |
| --- | --- |
| `data-walker` | `loading`, `ready` or `failed`. Follows the latest `modelUrl`. |
| `data-revealed` | Present (empty) once the canvas has faded in. |
| `data-quality-step` | Under `"auto"` only, and not while the still is shown: how many steps it has come down, from `0`. |
| `data-still` | Under reduced motion: `walker`, or `city` if the model wasn't in yet, set once the still is drawn, and removed when reduced motion is turned off. Absent while the container's size is changing: the still is then drawn as a draft at `"auto"`'s level until the size has held for 200 ms. |

## Pausing, reduced motion and no WebGL

- **Offscreen and hidden tabs.** The diorama stops drawing while the
  container is out of view or the tab is hidden, as well as after `pause()`,
  and starts again by itself (after `pause()`, on `resume()`).
- **Reduced motion.** Under `prefers-reduced-motion: reduce` it draws one
  still instead of the walk: the walker mid-stride with a short footprint
  trail, a few fragments in the air and one attack line breaking up at the
  shield. It shows at once, with no fade, at `"high"`'s settings (`"low"`'s
  under `quality: "low"`). The same container and options always give the
  same still; it is drawn again when they change. It follows the preference
  live: turning reduced motion off starts the walk from the still.
- **No WebGL 2.** `createDiorama` adds no canvas and returns a diorama whose
  methods do nothing. The container's own background shows, so give it a
  poster (below).

## Posters

A poster is a WebP of the frame the canvas reveals, walker included. Set one
as the container's CSS background, and the banner is never blank while loading, the canvas fades
in over a matching image, and browsers without WebGL see the poster:

```css
.hero {
  background: center / cover
    image-set(url(poster-1920x800.webp) 1x, url(poster-1920x800@2x.webp) 2x);
}
```

The posters for the demo's four presets (1920×800, 1440×480, 800×800,
390×700) are committed in [`public/posters/`](public/posters/), at 1× and 2×,
beside the reduced-motion stills (`still-<preset>.webp`). They aren't in the
package: copy the ones the page needs.

- A poster matches the canvas exactly only at its size and with the default
  `seed`, `focalPoint`, `zoom`, `azimuth`, `elevation`, `background` and
  `intensity.shield`. At other sizes the framing differs a little, so export
  posters at the page's own size and with its own options (below). A banner
  that changes size with the viewport needs one per breakpoint, switched with
  media queries; between breakpoints the framing is close, not exact.
- To show the still behind a reduced-motion page instead, use
  `still-<size>.webp` inside `@media (prefers-reduced-motion: reduce)`. The
  still is a later moment of the walk (about 4.65 s in), so it doesn't match
  the poster.
- With `background: "transparent"` a poster would need alpha. The script
  shoots over the demo's stage colour, so that isn't supported yet.
- If the model is slow to load (more than 2 s), the canvas reveals the city
  without the walker over a poster that has them, and the walker then fades
  in. This is rare and brief.

### Exporting posters

From a clone, with Playwright's Chromium installed (`npx playwright install
chromium`):

```sh
npm run posters                                        # the four presets
npm run posters -- --size 1600x700 --out public/banner # the page's own size
npm run posters -- --size 1600x700 --options '{"focalPoint":{"x":0.7}}'
```

It writes `poster-<size>.webp`, `poster-<size>@2x.webp`, `still-<size>.webp`
and `still-<size>@2x.webp` into `public/posters/` (or `--out <dir>`). The
second line above writes `poster-1600x700.webp` and the rest into
`public/banner/`.

- `--size WxH`: any container size, in whole CSS pixels up to 4096 a side.
  Repeatable. With `--size` alone, the presets are skipped.
- `--preset 1920x800`: one of the presets. Repeatable.
- `--dpr 2`: a pixel ratio. Repeatable; 1 and 2 when not given.
- `--options '<json>'`: the page's own options.
- `--out <dir>`: where to write.

It exits non-zero if the model didn't load or the page logged an error.

## The demo

```sh
npm install
npm run dev
```

opens the demo: a resizable container with the four presets and a panel with
every option. `?preset=1920x800` opens it at a preset; `?size=1600x700` at any
size.

`npm run build:demo` builds it into `dist-demo/`. The built demo loads the
model from `/models/walker.glb`, so it works only when hosted at the site
root.

## Scripts

| Command | What it does |
| --- | --- |
| `npm run build` | Builds the library into `dist/`: `hero-diorama.js`, its typings and `models/walker.glb`. `three` stays external. |
| `npm run release` | Tags a release (below). |
| `npm test` | Unit tests and browser tests (Vitest; the browser tests use Playwright's Chromium). |
| `npm run typecheck` | Type-checks the library and the scripts. |
| `npm run screenshots` | Screenshots the demo at every preset, at 1× and 2×. Takes `--preset`, `--dpr`, `--options` and `--out` like `posters`; `--reduced-motion` shoots the still. |
| `npm run posters` | Exports posters and stills (above). |
| `npm run measure:fps` | Measures a quality level: `npm run measure:fps -- --options '{"quality":"low"}'`. Prints mean fps, p95 frame time, the warm-up it took and the step `"auto"` ended on. It waits for steady state (at least 15 s, then until 2 s windows agree within 3%), uses Metal through ANGLE on macOS, and turns vsync off, so it measures throughput rather than the display's rate. |
| `npm run find-opening` | Searches for seeds with a good opening frame. |
| `npm run build:walker` | Rebuilds `public/models/walker.glb` (below). |
| `npm run check:walker` | Checks a walker GLB (below). |

## Releasing

Sites install a version tag (see [Installation](#installation)), so a
release is a tag that carries the built files:

1. Set `"version"` in `package.json` (e.g. `1.1.0`) and commit it on `main`.
2. `npm run release`. From a clean tree, it builds the library, commits
   `dist/` on top of `main` in a release commit that is on no branch, tags
   that commit `v1.1.0`, and checks `main` out again. It refuses a dirty tree
   or a tag that already exists.
3. `git push origin main v1.1.0`.

The release commit's `package.json` has no `scripts`. When a git dependency
has a `build`, `prepare` or install script, npm first installs all of that
package's dev dependencies in its clone and runs the script. Without scripts,
npm only copies the files. Checking `main` out again removes `dist/`; `npm run build`
brings it back.

## The walker model's build

`public/models/walker.glb` is generated from the Quaternius Universal
Animation Library (CC0) in `assets-src/quaternius-ual/`, which is never
edited. `npm run build:walker` keeps the `Mannequin` mesh, its skeleton and
the `Walk_Loop` clip, and drops the other clips and the UV sets (the walker is
untextured clay; the diorama swaps in its own material). Re-running it gives
the same bytes. It then runs `npm run check:walker`, which validates the file
and re-measures the walk's planted-foot speed through three's own loader, and
exits non-zero if any check fails. A replacement model passed as `modelUrl`
needs the same `Walk_Loop` clip and `ball_l`/`ball_r` bones; without the clip
the walker stands still.
